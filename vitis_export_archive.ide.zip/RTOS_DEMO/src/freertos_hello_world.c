/*
    Copyright (C) 2017 Amazon.com, Inc. or its affiliates.  All Rights Reserved.
    Copyright (c) 2012 - 2022 Xilinx, Inc. All Rights Reserved.
	SPDX-License-Identifier: MIT


    http://www.FreeRTOS.org
    http://aws.amazon.com/freertos


    1 tab == 4 spaces!
*/

/* FreeRTOS includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "timers.h"
#include "xsdps_core.h"


/*little fs includes */
#include "lfs.h"
#include "lfs_util.h"

/* Xilinx includes. */
#include "xil_printf.h"
#include "xparameters.h"

#define TIMER_ID	1
#define DELAY_10_SECONDS	10000UL
#define DELAY_1_SECOND		1000UL
#define TIMER_CHECK_THRESHOLD	9
//#define LFS_MALLOC pvPortMalloc
//#define LFS_FREE vPortFree
/*-----------------------------------------------------------*/

/* The Tx and Rx tasks as described at the top of this file. */
static void prvTxTask( void *pvParameters );
static void prvRxTask( void *pvParameters );
static void vTimerCallback( TimerHandle_t pxTimer );
static void makeFolder(void *pvParameters);
/*-----------------------------------------------------------*/

/* The queue used by the Tx and Rx tasks, as described at the top of this
file. */
static TaskHandle_t xTxTask;
static TaskHandle_t xRxTask;
static QueueHandle_t xQueue = NULL;
static TimerHandle_t xTimer = NULL;
char HWstring[15] = "Hello World";
long RxtaskCntr = 0;


//file-system specfic paramaters
lfs_t lfs;
lfs_file_t file;

// xsdps stuff
static XSdPs SdInstance;
//XSdPs *SdInstance;
XSdPs_Config *SdConfig;
int status;

#if (configSUPPORT_STATIC_ALLOCATION == 1)
#define QUEUE_BUFFER_SIZE		100

uint8_t ucQueueStorageArea[ QUEUE_BUFFER_SIZE ];
StackType_t xStack1[ configMINIMAL_STACK_SIZE ];
StackType_t xStack2[ configMINIMAL_STACK_SIZE ];
StaticTask_t xTxBuffer,xRxBuffer;
StaticTimer_t xTimerBuffer;
static StaticQueue_t xStaticQueue;
#endif


int lfs_xsdps_read(const struct lfs_config *c, lfs_block_t block,
					  lfs_off_t off, void *buffer, lfs_size_t size) {
	uint32_t blockAddr = block * (c->block_size / 512) + (off / 512);
	//uint32_t blockAddr = block * c->block_size + off;

	u32 blkCnt = size / 512;
	if (size % 512 != 0) blkCnt++;


	s32 result = XSdPs_ReadPolled(c->context, blockAddr, blkCnt, (u8 *)buffer);

	return result;
}

int lfs_xsdps_prog(const struct lfs_config *c, lfs_block_t block,
            lfs_off_t off, const void *buffer, lfs_size_t size) {
    uint32_t blockAddr = block * (c->block_size / 512) + (off / 512);
    u32 blkCnt = size / 512;
    if(size % 512 != 0) blkCnt++;

    //uint32_t blockAddr = block * c->block_size + off;

    s32 result = XSdPs_WritePolled(c->context, blockAddr, blkCnt, (const u8 *)buffer);

    return result;
}

int lfs_xsdps_erase(const struct lfs_config *c, lfs_block_t block) {
    uint32_t startAddr = block * c->block_size;
    uint32_t endAddr = (block + 1) * c->block_size - 1;

    s32 result = XSdPs_Erase(c->context, startAddr, endAddr);

    return result;
}

int lfs_xsdps_sync(const struct lfs_config *c) {
	LFS_ASSERT(0 < 1);
	return -1;
}

int main( void )
{
	const TickType_t x10seconds = pdMS_TO_TICKS( DELAY_10_SECONDS );

	xil_printf( "Hello from Freertos example main\r\n" );

	xil_printf("About To Test_FileSystem Creation");

	int counter = 0;
	counter++;

#ifdef SDT
	SdConfig = XSdPs_LookupConfig(XPAR_PSU_SD_0_DEVICE_ID);
#else
	SdConfig = XSdPs_LookupConfig(XPAR_PSU_SD_0_BASEADDR);
#endif
	assert(SdConfig != NULL);

	status = XSdPs_CfgInitialize(&SdInstance, SdConfig,
					     SdConfig->BaseAddress);
	assert(status != XST_FAILURE);

	status = XSdPs_CardInitialize(&SdInstance);
	assert(status != XST_FAILURE);

	const struct lfs_config cfg = {
	    // block device operations
		.context = &SdInstance,
	    .read  =  lfs_xsdps_read,
	    .prog  = lfs_xsdps_prog,
	    .erase = lfs_xsdps_erase,
	    .sync  = lfs_xsdps_sync,

	    // block device configuration
	    .read_size = 512,
	    .prog_size = 512,
	    .block_size = 512,
	    .block_count = 131072,
	    .cache_size = 512,
	    .lookahead_size = 512,
		.block_cycles = 512,
	};

	//xTaskCreate(makeFolder, "MakeFolder", configMINIMAL_STACK_SIZE, NULL,tskIDLE_PRIORITY + 1, NULL);


		int err = lfs_mount(&lfs, &cfg);

	    // reformat if we can't mount the filesystem
	    // this should only happen on the first boot
		if (err) {
	        lfs_format(&lfs, &cfg);
	        lfs_mount(&lfs, &cfg);
	    }




	    // read current count
	    //uint32_t boot_count = 0;
	    int result = lfs_file_open(&lfs, &file, "hello_there", LFS_O_RDWR | LFS_O_CREAT);
	    const char data[] = "Hello LittleFS!";
	    result = lfs_file_write(&lfs, &file, data, sizeof(data));
	    result = lfs_file_close(&lfs, &file);

	    /*
	    int result = lfs_mkdir(&lfs,"/my_directory");
	    if(result == 0) {
	    	xil_printf("Made a Folder");
	    }
	    else {
	    	xil_printf("Did not make a Folder");
	    }
	    */

	    uint32_t boot_count = 0;
	    result = lfs_file_open(&lfs, &file, "boot_count", LFS_O_RDWR | LFS_O_CREAT);
	    result = lfs_file_read(&lfs, &file, &boot_count, sizeof(boot_count));



	    // update boot count
	    boot_count += 1;
	    result = lfs_file_rewind(&lfs, &file);
	    result = lfs_file_write(&lfs, &file, &boot_count, sizeof(boot_count));
	    result = lfs_file_close(&lfs, &file);

	    // remember the storage is not updated until the file is closed successfully
	    // release any resources we were using
	    result = lfs_unmount(&lfs);


	    // print the boot count
	    //printf("boot_count: %d\n", boot_count);




#if ( configSUPPORT_STATIC_ALLOCATION == 0 ) /* Normal or standard use case */
	/* Create the two tasks.  The Tx task is given a lower priority than the
	Rx task, so the Rx task will leave the Blocked state and pre-empt the Tx
	task as soon as the Tx task places an item in the queue. */
	xTaskCreate( 	prvTxTask, 					/* The function that implements the task. */
					( const char * ) "Tx", 		/* Text name for the task, provided to assist debugging only. */
					configMINIMAL_STACK_SIZE, 	/* The stack allocated to the task. */
					NULL, 						/* The task parameter is not used, so set to NULL. */
					tskIDLE_PRIORITY,			/* The task runs at the idle priority. */
					&xTxTask );

	xTaskCreate( prvRxTask,
				 ( const char * ) "GB",
				 configMINIMAL_STACK_SIZE,
				 NULL,
				 tskIDLE_PRIORITY + 1,
				 &xRxTask );

	/* Create the queue used by the tasks.  The Rx task has a higher priority
	than the Tx task, so will preempt the Tx task and remove values from the
	queue as soon as the Tx task writes to the queue - therefore the queue can
	never have more than one item in it. */
	xQueue = xQueueCreate( 	1,						/* There is only one space in the queue. */
							sizeof( HWstring ) );	/* Each space in the queue is large enough to hold a uint32_t. */

	/* Check the queue was created. */
	configASSERT( xQueue );

	/* Create a timer with a timer expiry of 10 seconds. The timer would expire
	 after 10 seconds and the timer call back would get called. In the timer call back
	 checks are done to ensure that the tasks have been running properly till then.
	 The tasks are deleted in the timer call back and a message is printed to convey that
	 the example has run successfully.
	 The timer expiry is set to 10 seconds and the timer set to not auto reload. */
	xTimer = xTimerCreate( (const char *) "Timer",
							x10seconds,
							pdFALSE,
							(void *) TIMER_ID,
							vTimerCallback);
	/* Check the timer was created. */
	configASSERT( xTimer );

#else /* Use case where memories for tasks/queues/timers etc are provided statically by the users */
	xil_printf( "Using static memory for tasks, queue and timer creations. \r\n" );
	xTxTask = xTaskCreateStatic( 	prvTxTask, 				/* The function that implements the task. */
						( const char * ) "Tx", 					/* Text name for the task, provided to assist debugging only. */
						configMINIMAL_STACK_SIZE, 							/* The stack allocated to the task. */
						( void * ) NULL, 						/* The task parameter is not used, so set to NULL. */
						tskIDLE_PRIORITY,						/* The task runs at the idle priority. */
						xStack1,								/* Array to use the task's stack  */
						&xTxBuffer );               			/* variable to hold the task data structure */
	xRxTask =  xTaskCreateStatic( prvRxTask,
				 ( const char * ) "Rx",
				 configMINIMAL_STACK_SIZE,
				 ( void * ) NULL,
				 tskIDLE_PRIORITY + 1,
				 xStack2,
				 &xRxBuffer );

	xQueue = xQueueCreateStatic( 1,				/* Number of items in the queue. */
								sizeof( HWstring ),			/*size for each item to be stored in queue */
								ucQueueStorageArea,         /* Buffer to store the queue items*/
								&xStaticQueue);				/* Each space in the queue is large enough to hold a 1 byte. */
	/* Check the queue was created. */
	configASSERT( xQueue );
	xTimer = xTimerCreateStatic( (const char *) "Timer",
							x10seconds,
							pdFALSE,
							(void *) TIMER_ID,
							vTimerCallback,
							&xTimerBuffer);
	/* Check the timer was created. */
	configASSERT( xTimer );

#endif

	/* start the timer with a block time of 0 ticks. This means as soon
	   as the schedule starts the timer will start running and will expire after
	   10 seconds */
	xTimerStart( xTimer, 0 );

	/* Start the tasks and timer running. */
	vTaskStartScheduler();

	/* If all is well, the scheduler will now be running, and the following line
	will never be reached.  If the following line does execute, then there was
	insufficient FreeRTOS heap memory available for the idle and/or timer tasks
	to be created.  See the memory management section on the FreeRTOS web site
	for more details. */
	for( ;; );
}


static void makeFolder(void *pvParameters) {
	int result = lfs_mkdir(&lfs,"test");
	if(result == 0) {
		xil_printf("Made a Folder");
	}
	else {
		xil_printf("Did not make a Folder");
	}

}



/*-----------------------------------------------------------*/
static void prvTxTask( void *pvParameters )
{
const TickType_t x1second = pdMS_TO_TICKS( DELAY_1_SECOND );

	for( ;; )
	{
		/* Delay for 1 second. */
		vTaskDelay( x1second );

		/* Send the next value on the queue.  The queue should always be
		empty at this point so a block time of 0 is used. */
		xQueueSend( xQueue,			/* The queue being written to. */
					HWstring, /* The address of the data being sent. */
					0UL );			/* The block time. */
	}
}

/*-----------------------------------------------------------*/
static void prvRxTask( void *pvParameters )
{
char Recdstring[15] = "";

	for( ;; )
	{
		/* Block to wait for data arriving on the queue. */
		xQueueReceive( 	xQueue,				/* The queue being read. */
						Recdstring,	/* Data is read into this address. */
						portMAX_DELAY );	/* Wait without a timeout for data. */

		/* Print the received data. */
		xil_printf( "Rx task received string from Tx task: %s\r\n", Recdstring );
		RxtaskCntr++;
	}
}

/*-----------------------------------------------------------*/
static void vTimerCallback( TimerHandle_t pxTimer )
{
	long lTimerId;
	configASSERT( pxTimer );

	lTimerId = ( long ) pvTimerGetTimerID( pxTimer );

	if (lTimerId != TIMER_ID) {
		xil_printf("FreeRTOS Hello World Example FAILED");
	}

	/* If the RxtaskCntr is updated every time the Rx task is called. The
	 Rx task is called every time the Tx task sends a message. The Tx task
	 sends a message every 1 second.
	 The timer expires after 10 seconds. We expect the RxtaskCntr to at least
	 have a value of 9 (TIMER_CHECK_THRESHOLD) when the timer expires. */
	if (RxtaskCntr >= TIMER_CHECK_THRESHOLD) {
		xil_printf("Successfully ran FreeRTOS Hello World Example");
	} else {
		xil_printf("FreeRTOS Hello World Example FAILED");
	}

	vTaskDelete( xRxTask );
	vTaskDelete( xTxTask );
}
